package vcg.Config

import net.mamoe.mirai.console.data.AutoSavePluginConfig
import net.mamoe.mirai.console.data.value
import vcg.Utils.Resources

object Config : AutoSavePluginConfig("${Resources.NAME}Config") {
//    var imageAPI: String by value(Resources.IMG_API_URL)
    var imageAPIList: List<String> by value(arrayListOf(Resources.IMG_API_URL))

    // 群发配置
    var groupList: List<Long> by value(
        arrayListOf(620615452L, 456906519L, 133808502L, 399742302L, 318251170L, 1035459278L))

    var friendList: List<Long> by value(
        arrayListOf(296711867L, 2779072927L, 3110985822L))

    // 命令前缀
    var commandPrefix: String by value(Resources.COMMAND_PREFIX)

    // 图片存储地方
    var imageStorage: String by value(Resources.IMG_STORAGE_PATH)

//    var cmd: List<String> by value(arrayListOf("calendar", "img"))

    // Command Switch Config
//    var help: Boolean by value(Resources.help)
//    var calendar: Boolean by value(Resources.cl)
//    var img: Boolean by value(Resources.img)

    // Customized Setting for Command
    var getRandImageCD: Int by value(10000)
}