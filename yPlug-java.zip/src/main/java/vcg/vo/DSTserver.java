package vcg.vo;

public class DSTserver {

    public String[] List;

    public void setList(String[] List)
    {
        this.List = List;
    }

    public String[] getList()
    {
        return List;
    }




}
